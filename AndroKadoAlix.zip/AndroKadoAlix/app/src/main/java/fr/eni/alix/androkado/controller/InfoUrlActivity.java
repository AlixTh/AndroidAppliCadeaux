package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import org.parceler.Parcels;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Article;


public class InfoUrlActivity extends AppCompatActivity {

    public static final String EXTRA_PARAMETRE = "parametre";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_url);
        setTitle("AndroKado: Ville de l'article");

        ArticleDTO articleDTO = Parcels.unwrap(getIntent().getParcelableExtra(EXTRA_PARAMETRE));

        //Toast.makeText(this, article1.url, Toast.LENGTH_SHORT).show();

    }
}