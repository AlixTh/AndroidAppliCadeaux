package fr.eni.alix.androkado.fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import org.parceler.Parcels;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.controller.ArticleActivity;
import fr.eni.alix.androkado.controller.InfoUrlActivity;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Article;


public class DetailFragment extends Fragment
{
    public static final String EXTRA_ARTICLE = "article";
    public TextView textViewArticleName;
    public TextView textViewArticlePrice;
    public RatingBar ratingBarArticleNote;
    public TextView textViewArticleDetails;
    public ImageButton mImageButton;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        Bundle bundle = getArguments();

        if (bundle != null)
        {
            ArticleDTO articleDTO = Parcels.unwrap(bundle.getParcelable(EXTRA_ARTICLE));
            textViewArticleName = view.findViewById(R.id.articleDetailName);
            textViewArticlePrice = view.findViewById(R.id.articleDetailPrice);
            ratingBarArticleNote = view.findViewById(R.id.ratingBarDetail);
            textViewArticleDetails = view.findViewById(R.id.articleDetailDetails);
            mImageButton = view.findViewById(R.id.buttonDetailEarth);

            textViewArticleName.setText(articleDTO.name);
            textViewArticlePrice.setText(articleDTO.price + " euros");
            ratingBarArticleNote.setRating(articleDTO.note);
            textViewArticleDetails.setText(articleDTO.description);

            mImageButton.setOnClickListener(view1 -> {
                Toast.makeText(view.getContext(), articleDTO.url, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(view.getContext(), InfoUrlActivity.class);
                intent.putExtra(InfoUrlActivity.EXTRA_PARAMETRE, Parcels.wrap(articleDTO));
                startActivity(intent);
            });
        }

    }

}