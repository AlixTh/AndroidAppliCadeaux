package fr.eni.alix.androkado.metier.bdd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper
{
    // Constructeur :
    public DatabaseHelper(Context context)
    {
        super(context, "articles.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE " + BaseContrat.ArticlesContrat.TABLE_ARTICLES + " ("
                + BaseContrat.ArticlesContrat._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + BaseContrat.ArticlesContrat.COLONNE_NAME + " TEXT NOT NULL, "
                + BaseContrat.ArticlesContrat.COLONNE_DESCRIPTION + " TEXT NOT NULL, "
                + BaseContrat.ArticlesContrat.COLONNE_PRICE + " FLOAT NOT NULL, "
                + BaseContrat.ArticlesContrat.COLONNE_NOTE + " FLOAT NOT NULL, "
                + BaseContrat.ArticlesContrat.COLONNE_URL + " TEXT NOT NULL "
                + ")");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    }

}
