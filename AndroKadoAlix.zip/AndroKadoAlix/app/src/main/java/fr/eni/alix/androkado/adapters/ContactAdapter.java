package fr.eni.alix.androkado.adapters;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.controller.ContactsActivity;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Contact;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactViewHolder>
{

    private List<Contact> listeContact;
    private ContactsActivity contactsActivity;
    private ArticleDTO articleDTO;

    private static final String LOG_TAG = "AndroidExample";

    public ContactAdapter(List<Contact> listeContact, ContactsActivity contactsActivity, ArticleDTO articleDTO)
    {
        this.listeContact = listeContact;
        this.contactsActivity = contactsActivity;
        this.articleDTO = articleDTO;
    }
    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View viewContact = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item_contact, parent, false);
        return new ContactViewHolder(viewContact);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position)
    {
        holder.mTextViewContactName.setText(listeContact.get(position).nom);
        holder.mTextViewContactNumber.setText(listeContact.get(position).numero);
    }

    @Override
    public int getItemCount() {
        return listeContact.size();
    }

    public void updateContacts(List<Contact> listeContact)
    {
        this.listeContact = listeContact;
        notifyDataSetChanged();
    }

    class ContactViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextViewContactName;
        public TextView mTextViewContactNumber;


        public ContactViewHolder(@NonNull View itemView) {
            super(itemView);
            mTextViewContactName = itemView.findViewById(R.id.contactName);
            mTextViewContactNumber = itemView.findViewById(R.id.contactNumber);



            itemView.setOnClickListener(view -> {
                Contact contact = listeContact.get(getAdapterPosition());
                Toast.makeText(view.getContext(), "Contact !", Toast.LENGTH_SHORT).show();
                String message = "J'aimerais cet article : " + articleDTO.name;

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT, message);
                intent.putExtra(Intent.EXTRA_PHONE_NUMBER, contact.numero);
                intent.setType("text/plain");
                //Intent chooser = Intent.createChooser(intent, "Envoyer à :");

                if (intent.resolveActivity(itemView.getContext().getPackageManager()) != null){
                    itemView.getContext().startActivity(intent);
                }
            });
        }
    }



}
