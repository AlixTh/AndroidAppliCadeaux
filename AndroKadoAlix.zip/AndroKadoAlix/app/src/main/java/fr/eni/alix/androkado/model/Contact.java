package fr.eni.alix.androkado.model;

import org.parceler.Parcel;

@Parcel
public class Contact
{
    public String nom;
    public String numero;


    public Contact(){}

    public Contact(String nom, String numero) {
        this.nom = nom;
        this.numero = numero;
    }
}
