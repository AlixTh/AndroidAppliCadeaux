package fr.eni.alix.androkado.metier.dto;

import org.parceler.Parcel;

@Parcel
public class ArticleDTO
{
    public long id;
    public String name;
    public String description;
    public float price;
    public float note;
    public String url;

    public ArticleDTO() {}

    public ArticleDTO(long id, String name, String description, float price, float note, String url) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.note = note;
        this.url = url;
    }
}
