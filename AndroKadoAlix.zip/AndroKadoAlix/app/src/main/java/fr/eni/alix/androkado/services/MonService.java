package fr.eni.alix.androkado.services;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import fr.eni.alix.androkado.controller.DemoEventServiceActivity;

public class MonService extends Service {

    private static final String TAG = "MonService";
    public static final String EXTRA_COMMANDE = "commande";

    @Override
    public void onCreate()
    {
        super.onCreate();
        Log.i(TAG, "onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        String commande = intent.getStringExtra(EXTRA_COMMANDE);
        Log.d(TAG, "onStartCommand: commande = " + commande);

        if ("play".equals(commande))
        {
            play();
        }
        return START_REDELIVER_INTENT;
    }


    private void play()
    {
        new Thread(() -> {

            for (int a = 0 ; a <= 30 ; a++)
            {
                try
                {
                    Thread.sleep(1000);

                    final int progression = a;
                    new Handler(Looper.getMainLooper()).post(() -> {

                        // de nouveau dans le thread UI :
                        Intent intentBR = new Intent();
                        intentBR.setAction(DemoEventServiceActivity.MonBroadcastReceiver.INTENT_FILTER);
                        intentBR.putExtra(DemoEventServiceActivity.MonBroadcastReceiver.EXTRA_PROGRESSION, progression);
                        sendBroadcast(intentBR);
                    });
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }

        }).start();
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        Log.w(TAG, "onDestroy");
    }


    private final IBinder binder = new MonBinder();


    public class MonBinder extends Binder
    {
        public MonService getService()
        {
            return MonService.this;
        }
    }


    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public String getTitreCourant()
    {
        return "David Bowie - Heroes";
    }
}