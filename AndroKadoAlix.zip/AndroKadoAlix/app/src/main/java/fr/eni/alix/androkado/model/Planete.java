package fr.eni.alix.androkado.model;

public class Planete
{
    public String name;
    public int rotation_period;
    public int orbital_period;
    public int diameter;
}
