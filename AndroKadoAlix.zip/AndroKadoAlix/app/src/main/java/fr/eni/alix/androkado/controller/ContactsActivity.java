package fr.eni.alix.androkado.controller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import org.parceler.Parcels;

import java.util.List;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.adapters.ContactAdapter;
import fr.eni.alix.androkado.metier.dao.ContactsDAO;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Contact;

public class ContactsActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_AUTORISATION = 456;
    private RecyclerView recyclerView;
    private ContactAdapter mContactAdapter;
    private ArticleDTO articleDTO;

    public static final String EXTRA_ARTICLE2 = "article2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        setTitle("AndroKado: Liste de contacts");

        int permission = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        if (permission == PackageManager.PERMISSION_GRANTED)
        {
            lireContacts();
        }
        else
        {
            // affichage de la popup de demande de permission :
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    ContactsActivity.REQUEST_CODE_AUTORISATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_AUTORISATION)
        {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                // permission accordée, on peut accéder aux contacts sans risque :
                lireContacts();
            }
            else
            {
                // permission refusée, on ne peut pas accéder aux contacts :
                Toast.makeText(this, "Autorisation refusée !!!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void lireContacts() {
        recyclerView = findViewById(R.id.liste_contacts);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        List<Contact> listeContacts = ContactsDAO.getListeContacts(this);

        articleDTO = Parcels.unwrap(getIntent().getParcelableExtra(EXTRA_ARTICLE2));

        mContactAdapter = new ContactAdapter(listeContacts, this, articleDTO);
        recyclerView.setAdapter(mContactAdapter);

    }
}