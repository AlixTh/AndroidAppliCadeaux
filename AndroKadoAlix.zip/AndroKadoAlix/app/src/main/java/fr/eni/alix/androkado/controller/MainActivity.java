package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import fr.eni.alix.androkado.R;

public class MainActivity extends AppCompatActivity {
    private Button mButtonActivityArticle;
    private Button mButtonActivityRetrofit;
    private Button mButtonActivityThread;
    private Button mButtonActivityService;
    private Button mButtonActivityBroadCast;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButtonActivityArticle = findViewById(R.id.buttonActivityArticle);
        mButtonActivityRetrofit = findViewById(R.id.buttonActivityRetrofit);
        mButtonActivityThread = findViewById(R.id.buttonActivityThreads);
        mButtonActivityService = findViewById(R.id.buttonActivityServices);
        mButtonActivityBroadCast = findViewById(R.id.buttonActivityBroadcast);


        mButtonActivityArticle.setOnClickListener(view -> {
            Intent intent = new Intent(this, ListArticlesActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        mButtonActivityRetrofit.setOnClickListener(view -> {
            Intent intent = new Intent(this, RetrofitActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        mButtonActivityThread.setOnClickListener(view -> {
            Intent intent = new Intent(this, ThreadActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        mButtonActivityService.setOnClickListener(view -> {
            Intent intent = new Intent(this, DemoServiceActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        mButtonActivityBroadCast.setOnClickListener(view -> {
            Intent intent = new Intent(this, DemoEventServiceActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

    }
}