package fr.eni.alix.androkado.metier.ws;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitSingleton
{
    private static RetrofitSingleton instance = null;
    public Retrofit retrofit;


    // Getter singleton :
    public static Retrofit getRetrofit()
    {
        if (instance == null)
        {
            instance = new RetrofitSingleton();
        }
        return instance.retrofit;
    }

    // Constructeur privé :
    private RetrofitSingleton()
    {
        retrofit = new Retrofit.Builder()
                .baseUrl("https://swapi.dev/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }
}
