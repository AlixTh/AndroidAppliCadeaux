package fr.eni.alix.androkado.controller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.metier.ws.ReseauHelper;
import fr.eni.alix.androkado.metier.ws.RetrofitSingleton;
import fr.eni.alix.androkado.metier.ws.WSInterface;
import fr.eni.alix.androkado.model.Planete;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RetrofitActivity extends AppCompatActivity
{
    private static final String TAG = "RetrofitActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrofit);
        setTitle("AndroKado: Retrofit");
    }

    public void clicBoutonPlanete(View view)
    {

        // vérification connexion internet :
        if (!ReseauHelper.estConnecte(this))
        {
            Toast.makeText(this, "Aucune connexion internet !", Toast.LENGTH_SHORT).show();
            return;
        }

        // appel webservice :
        WSInterface service = RetrofitSingleton.getRetrofit().create(WSInterface.class);
        Call<Planete> call =  service.getPlanete(1);
        call.enqueue(new Callback<Planete>()
        {
            @Override
            public void onResponse(@NonNull Call<Planete> call, @NonNull Response<Planete> response)
            {
                if (response.isSuccessful())
                {
                    Planete planete = response.body();
                    if (planete != null)
                    {
                        Log.d(TAG, "planete : "
                                + planete.name + " - "
                                + planete.rotation_period + " - "
                                + planete.orbital_period + " - "
                                + planete.diameter);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<Planete> call, @NonNull Throwable t)
            {
                t.printStackTrace();
            }
        });
    }
}