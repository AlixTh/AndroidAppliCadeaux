package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import org.parceler.Parcels;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.metier.dao.ArticlesDAO;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;

public class DeleteActivity extends AppCompatActivity {
    private Button mButtonSupprimer;
    private Button mButtonAnnuler;
    public static final String EXTRA_ARTICLE_DELETE = "articleDelete";
    private ArticleDTO articleDTO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        setTitle("AndroKado: Supprimer un article");

        mButtonSupprimer = findViewById(R.id.buttonSupprimer);
        mButtonAnnuler = findViewById(R.id.buttonAnnuler);

        articleDTO = Parcels.unwrap(getIntent().getParcelableExtra(EXTRA_ARTICLE_DELETE));

        mButtonSupprimer.setOnClickListener(view -> {
           ArticlesDAO.deleteArticle(articleDTO, this);

            Intent intent1 = new Intent(this, ListArticlesActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent1);
        });

        mButtonAnnuler.setOnClickListener(view -> {
            Intent intent1 = new Intent(this, ListArticlesActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent1);
        });

    }
}