package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import fr.eni.alix.androkado.R;

public class ThreadActivity extends AppCompatActivity {

    private static final String TAG = "ThreadActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thread);
    }

    @SuppressLint("SetTextI18n")
    public void clicBoutonThread(View view)
    {
        Log.i(TAG, "clicBoutonThread: avant thread");
        Button bouton = findViewById(R.id.bouton);

        new Thread(() -> {

            // traitements dans un thread séparé :
            for (long a = 0 ; a <= 100_000_000 ; a++)
            {
                if (a % 10_000_000 == 0)
                {
                    final long b = a;
                    runOnUiThread(() -> bouton.setText("étape : " + b));
                }
            }
        }).start();

        Log.i(TAG, "clicBoutonThread: après thread");
    }
}