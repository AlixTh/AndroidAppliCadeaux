package fr.eni.alix.androkado.controller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.parceler.Parcels;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.fragments.DetailFragment;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Article;

public class DetailActivity extends AppCompatActivity
{
    public static final String EXTRA_ARTICLE = "article";

    private ArticleDTO articleDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setTitle("AndroKado: Détail de l'article");

        //récupération de l'article :
        articleDTO = Parcels.unwrap(getIntent().getParcelableExtra(EXTRA_ARTICLE));



        //fragment :
        DetailFragment fragment = new DetailFragment();

        //argument :
        Bundle bundle = new Bundle();
        bundle.putParcelable(DetailFragment.EXTRA_ARTICLE, Parcels.wrap(articleDTO));
        fragment.setArguments(bundle);

        //ajout :
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.conteneur_fragment, fragment, "tagdetail");
        transaction.commit();
    }


    //Permet de faire apparaitre un menu choisi des xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_menu_detailsarticles, menu);
        return super.onCreateOptionsMenu(menu);
    }


    //Pour faire marcher les clics des boutons du menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.action_detail_delete:
                Toast.makeText(this, "Supprimer !", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(this, DeleteActivity.class);
                intent2.putExtra(DeleteActivity.EXTRA_ARTICLE_DELETE, Parcels.wrap(articleDTO));
                startActivity(intent2);
                return true;
            case R.id.action_detail_edit:
                Toast.makeText(this, "Modifier", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, ArticleActivity.class);
                intent.putExtra(ArticleActivity.EXTRA_ARTICLE, Parcels.wrap(articleDTO));
                startActivity(intent);
                return true;
            case R.id.action_detail_send:
                Toast.makeText(this, "Envoyer", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(this, ContactsActivity.class);
                intent1.putExtra(ContactsActivity.EXTRA_ARTICLE2, Parcels.wrap(articleDTO));
                startActivity(intent1);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }
}