package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import org.parceler.Parcels;

import java.util.List;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.adapters.ArticlesAdapter;
import fr.eni.alix.androkado.metier.dao.ArticlesDAO;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;


public class ArticleActivity extends AppCompatActivity {
    private EditText mArticleName;
    private EditText mArticleDescription;
    private EditText mArticlePrice;
    private EditText mArticleNote;
    private EditText mArticleUrl;
    private AppCompatButton mArticleValider;

    private int triPrixInt;
    private ArticlesAdapter articlesAdapter;
    private ArticleDTO articleDTO;

    public static final String EXTRA_ARTICLE = "article";

    private boolean addEdit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article);
        setTitle("AndroKado: Création/Modification d'article");

        mArticleName = findViewById(R.id.articleEditName);
        mArticleDescription = findViewById(R.id.articleEditDescription);
        mArticlePrice = findViewById(R.id.articleEditPrice);
        mArticleNote = findViewById(R.id.articleEditNote);
        mArticleUrl = findViewById(R.id.articleEditURL);
        mArticleValider = findViewById(R.id.articleValider);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String prixDefaut = preferences.getString(ConfigurationActivity.CLE_PRIX_DEFAUT, "");

        mArticlePrice.setText(prixDefaut);

        if (Parcels.unwrap(getIntent().getParcelableExtra(EXTRA_ARTICLE)) != null)
        {
           articleDTO = Parcels.unwrap(getIntent().getParcelableExtra(EXTRA_ARTICLE));
           mArticleName.setText(articleDTO.name);
           mArticleDescription.setText(articleDTO.description);
           mArticlePrice.setText(articleDTO.price+"");
           mArticleNote.setText(articleDTO.note+"");
           mArticleUrl.setText(articleDTO.url);

           addEdit = true;
        }

        mArticleValider.setOnClickListener(view -> {
            if (addEdit){

                articleDTO.name = mArticleName.getText().toString();
                articleDTO.description = mArticleDescription.getText().toString();
                articleDTO.price = Float.parseFloat(mArticlePrice.getText().toString());
                articleDTO.note = Float.parseFloat(mArticleNote.getText().toString());
                articleDTO.url = mArticleUrl.getText().toString();

                ArticlesDAO.updateArticle(articleDTO, this);

                Boolean triPrix = preferences.getBoolean(ConfigurationActivity.CLE_TRI, false);
                if (triPrix) {
                    triPrixInt = 1;
                } else {
                    triPrixInt = 0;
                }

            }
            if (!addEdit){
                articleDTO = new ArticleDTO(
                        0,
                        mArticleName.getText().toString(),
                        mArticleDescription.getText().toString(),
                        Float.parseFloat(mArticlePrice.getText().toString()),
                        Float.parseFloat(mArticleNote.getText().toString()),
                        mArticleUrl.getText().toString());

                ArticlesDAO.ajouterArticle(articleDTO, this);

                Boolean triPrix = preferences.getBoolean(ConfigurationActivity.CLE_TRI, false);
                if (triPrix) {
                    triPrixInt = 1;
                } else {
                    triPrixInt = 0;
                }

                List<ArticleDTO> listeArticles = ArticlesDAO.getListeArticles(this, triPrixInt);
                articlesAdapter.updateArticles(listeArticles);
            }

            Intent intent1 = new Intent(this, ListArticlesActivity.class);
            intent1.addFlags(intent1.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent1);
        });
    }

}