package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.services.MonService;

public class DemoEventServiceActivity extends AppCompatActivity {


    // Broadcast receiver :
    private MonBroadcastReceiver monBroadcastReceiver = null;

    // Vues :
    private ProgressBar progressBar = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_event_service);
        // vues :
        progressBar = findViewById(R.id.progressbar);

        // broadcast :
        monBroadcastReceiver = new MonBroadcastReceiver();
    }

    public void clicBoutonPlay(View view)
    {
        Intent intent = new Intent(this, MonService.class);
        intent.putExtra(MonService.EXTRA_COMMANDE, "play");
        startService(intent);
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        registerReceiver(monBroadcastReceiver, new IntentFilter(MonBroadcastReceiver.INTENT_FILTER));
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        unregisterReceiver(monBroadcastReceiver);
    }


    /**
     * Broadcast receiver.
     */
    public class MonBroadcastReceiver extends BroadcastReceiver
    {
        public static final String INTENT_FILTER = "com.example.demoappjava6.INFO_LECTEUR";
        public static final String EXTRA_PROGRESSION = "progression";

        @Override
        public void onReceive(Context context, Intent intent)
        {
            int progression = intent.getIntExtra(EXTRA_PROGRESSION, 0);
            progressBar.setProgress(progression);
        }
    }
}