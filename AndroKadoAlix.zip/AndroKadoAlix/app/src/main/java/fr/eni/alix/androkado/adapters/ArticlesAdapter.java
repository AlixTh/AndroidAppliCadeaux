package fr.eni.alix.androkado.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import org.parceler.Parcels;

import java.util.List;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.controller.DetailActivity;
import fr.eni.alix.androkado.controller.ListArticlesActivity;
import fr.eni.alix.androkado.fragments.DetailFragment;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Article;

public class ArticlesAdapter extends RecyclerView.Adapter<ArticlesAdapter.ArticleViewHolder>
{

    private List<ArticleDTO> listeArticles;
    private ListArticlesActivity listArticlesActivity;

    public ArticlesAdapter(List<ArticleDTO> listeArticles, ListArticlesActivity listArticlesActivity) {
        this.listeArticles = listeArticles;
        this.listArticlesActivity = listArticlesActivity;
    }

    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View viewArticle = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item_article, parent, false);
        return new ArticleViewHolder(viewArticle);
    }

    @SuppressLint("SetTextI18n") //A ne pas faire dans un réel projet
    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, int position)
    {
        holder.textViewArticleName.setText(listeArticles.get(position).name);
        holder.ratingBarArticleNote.setRating(listeArticles.get(position).note);
    }

    @Override
    public int getItemCount() {
        return listeArticles.size();
    }

    public void ajouterArticle(Article article)
    {
//        listeArticles.add(0, article);
//        notifyItemInserted(0);
    }

    public void updateArticles(List<ArticleDTO> listeArticles)
    {
        this.listeArticles = listeArticles;
        notifyDataSetChanged();
    }

    class ArticleViewHolder extends RecyclerView.ViewHolder
    {

        public TextView textViewArticleName;
        public RatingBar ratingBarArticleNote;

        public ArticleViewHolder(@NonNull View itemView)
        {
            super(itemView);
            textViewArticleName = itemView.findViewById(R.id.articleName);
            ratingBarArticleNote = itemView.findViewById(R.id.ratingBar);

            itemView.setOnClickListener(view -> {

                ArticleDTO articleDTO = listeArticles.get(getAdapterPosition());

                if (listArticlesActivity.findViewById(R.id.conteneur_fragment) != null)
                {
                    //fragment :
                    DetailFragment fragment = new DetailFragment();

                    //argument :
                    Bundle bundle = new Bundle();
                    bundle.putParcelable(DetailFragment.EXTRA_ARTICLE, Parcels.wrap(articleDTO));
                    fragment.setArguments(bundle);

                    //ajout :
                    FragmentTransaction transaction = listArticlesActivity.getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.conteneur_fragment, fragment, "tagdetail");
                    transaction.commit();
                }else
                {
                    Intent intent = new Intent(itemView.getContext(), DetailActivity.class);
                    intent.putExtra(DetailActivity.EXTRA_ARTICLE, Parcels.wrap(articleDTO));
                    itemView.getContext().startActivity(intent);
                }


            });
        }
    }

}
