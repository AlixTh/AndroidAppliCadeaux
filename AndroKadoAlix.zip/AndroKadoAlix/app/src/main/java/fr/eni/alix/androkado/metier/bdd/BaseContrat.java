package fr.eni.alix.androkado.metier.bdd;

import android.provider.BaseColumns;

public class BaseContrat {

    // constructeur privé afin de ne pas instancier la classe :
    private BaseContrat() {}

    // contenu de la table "articles" :
    public static class ArticlesContrat implements BaseColumns
    {
        public static final String TABLE_ARTICLES = "articles";
        public static final String COLONNE_NAME = "name";
        public static final String COLONNE_DESCRIPTION = "description";
        public static final String  COLONNE_PRICE = "price";
        public static final String  COLONNE_NOTE = "note";
        public static final String  COLONNE_URL = "url";
    }
}
