package fr.eni.alix.androkado.controller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.adapters.ArticlesAdapter;
import fr.eni.alix.androkado.metier.bdd.DatabaseHelper;
import fr.eni.alix.androkado.metier.dao.ArticlesDAO;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Article;

public class ListArticlesActivity extends AppCompatActivity {

    private ArticlesAdapter articlesAdapter;
    private  RecyclerView recyclerView;
    private int triPrixInt;
    private List<ArticleDTO> listeArticles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_articles);
        setTitle("AndroKado: Liste d'articles");

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        databaseHelper.getWritableDatabase();


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        Boolean triPrix = preferences.getBoolean(ConfigurationActivity.CLE_TRI, false);
        if (triPrix){
            triPrixInt = 1;
        }else {
            triPrixInt = 0;
        }

        recyclerView = findViewById(R.id.liste_articles);

        //A ajouter pour de meilleures performances --> peut importe ce que l'on va mettre comme items dans la liste, la vue ne bougera pas
        recyclerView.setHasFixedSize(true);

        //layout manager, décrivant comment les items sont disposés
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //liste d'exemple
        listeArticles = ArticlesDAO.getListeArticles(this, triPrixInt);

        //adapter
        articlesAdapter = new ArticlesAdapter(listeArticles, this);
        recyclerView.setAdapter(articlesAdapter);
    }

    //Permet de faire apparaitre un menu choisi des xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_menu_liste, menu);
        return super.onCreateOptionsMenu(menu);
    }


    //Pour faire marcher les clics des boutons du menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.action_liste_ajout:
                Toast.makeText(this, "Ajout", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(this, ArticleActivity.class);
                startActivity(intent1);
                return true;
            case R.id.action_liste_configutation:
                Toast.makeText(this, "Configuration", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, ConfigurationActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}