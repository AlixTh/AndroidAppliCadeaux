package fr.eni.alix.androkado.metier.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.ContactsContract;

import java.util.ArrayList;
import java.util.List;

import fr.eni.alix.androkado.metier.bdd.BaseContrat;
import fr.eni.alix.androkado.metier.bdd.DatabaseHelper;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;
import fr.eni.alix.androkado.model.Contact;

public class ContactsDAO
{
    private static DatabaseHelper databaseHelper;
    private static SQLiteDatabase db;
    private static Cursor cursor;
    private static String selection;
    private static String[] selectionArgs;
    private static ContentValues values;

    @SuppressLint("Range")
    public static List<Contact> getListeContacts(Context context)
    {
        //tri :
        String tri = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC ";

        //requête :
        cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,  //table requêté
                null, //colonnes à retourner
                null, //colonnes WHERE
                null, //valeurs WHERE
                tri); //ordre de tri
        List<Contact> listeContacts = new ArrayList<>();
        if (cursor != null)
        {
            try
            {
                while (cursor.moveToNext())
                {
                    // conversion des données remontées en un objet métier :
                    listeContacts.add(new Contact(
                            cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)),
                            cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                            ));
                }
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
            finally
            {
                cursor.close();
            }
        }

        return listeContacts;


    }

}
