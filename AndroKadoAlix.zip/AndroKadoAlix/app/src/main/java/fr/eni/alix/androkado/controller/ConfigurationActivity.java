package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Switch;

import java.util.List;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.adapters.ArticlesAdapter;
import fr.eni.alix.androkado.metier.dao.ArticlesDAO;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;

public class ConfigurationActivity extends AppCompatActivity {
    public Switch mSwitchTri;
    public EditText mEditTextPrix;

    public final static String CLE_TRI = "CLE_TRI";
    public final static String CLE_PRIX_DEFAUT = "CLE_PRIX_DEFAUT";

    private int triPrixInt;
    private ArticlesAdapter articlesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuration);
        setTitle("AndroKado: Configuration");


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        Boolean triPrix = preferences.getBoolean(CLE_TRI, false);
        String prixDefaut = preferences.getString(CLE_PRIX_DEFAUT, "");

        mSwitchTri = findViewById(R.id.configuration_switch_tri);
        mEditTextPrix = findViewById(R.id.configuration_edit_prix);

        mSwitchTri.setChecked(triPrix);
        mEditTextPrix.setText(prixDefaut);

    }

    @Override
    protected void onStop() {
        super.onStop();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(CLE_TRI, mSwitchTri.isChecked());
        editor.putString(CLE_PRIX_DEFAUT, mEditTextPrix.getText().toString());
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent1 = new Intent(this, ListArticlesActivity.class);
        intent1.addFlags(intent1.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent1);
    }
}