package fr.eni.alix.androkado.metier.dao;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import fr.eni.alix.androkado.metier.bdd.BaseContrat;
import fr.eni.alix.androkado.metier.bdd.DatabaseHelper;
import fr.eni.alix.androkado.metier.dto.ArticleDTO;

public class ArticlesDAO {
    private static DatabaseHelper databaseHelper;
    private static SQLiteDatabase db;
    private static Cursor cursor;
    private static String selection;
    private static String[] selectionArgs;
    private static ContentValues values;

    @SuppressLint("Range")
    public static List<ArticleDTO> getListeArticles(Context context, int Boolentri)
    {
        String tri;

        // récupération de la base de données :
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getReadableDatabase();

        // tri :
        if (Boolentri == 1){
            tri = BaseContrat.ArticlesContrat.COLONNE_PRICE + " ASC " ;
        }else{
            tri = null;
        }

        // requète :
        cursor = db.query(
                false, // true si SELECT DISTINCT
                BaseContrat.ArticlesContrat.TABLE_ARTICLES, // table sur laquelle faire la requète
                null, // colonnes à retourner
                null, // colonnes pour la clause WHERE
                null, // valeurs pour la clause WHERE
                null, // GROUP BY (inactif)
                null, // HAVING (inactif)
                tri, // ordre de tri
                null); // LIMIT (inactif)

        List<ArticleDTO> listeArticles = new ArrayList<>();
        if (cursor != null)
        {
            try
            {
                while (cursor.moveToNext())
                {
                    // conversion des données remontées en un objet métier :
                    listeArticles.add(new ArticleDTO(
                            cursor.getLong(cursor.getColumnIndex(BaseContrat.ArticlesContrat._ID)),
                            cursor.getString(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_NAME)),
                            cursor.getString(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_DESCRIPTION)),
                            cursor.getFloat(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_PRICE)),
                            cursor.getFloat(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_NOTE)),
                            cursor.getString(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_URL))));
                }
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
            finally
            {
                cursor.close();
            }
        }
        return listeArticles;
    }


    @SuppressLint("Range")
    public static ArticleDTO getArticle (Context context, long id)
    {
        selection = BaseContrat.ArticlesContrat._ID + " = ?";
        selectionArgs = new String[]{id + ""};

        // récupération de la base de données :
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getReadableDatabase();

        // requète :
        cursor = db.query(
                false, // true si SELECT DISTINCT
                BaseContrat.ArticlesContrat.TABLE_ARTICLES, // table sur laquelle faire la requète
                null, // colonnes à retourner
                selection, // colonnes pour la clause WHERE
                selectionArgs, // valeurs pour la clause WHERE
                null, // GROUP BY (inactif)
                null, // HAVING (inactif)
                null, // ordre de tri
                null); // LIMIT (inactif)

        ArticleDTO articleDTO = new ArticleDTO();

        if (cursor != null)
        {
            try
            {
                while (cursor.moveToNext())
                {
                    // conversion des données remontées en un objet métier :
                    articleDTO.id = cursor.getLong(cursor.getColumnIndex(BaseContrat.ArticlesContrat._ID));
                    articleDTO.name = cursor.getString(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_NAME));
                    articleDTO.description = cursor.getString(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_DESCRIPTION));
                    articleDTO.price = cursor.getFloat(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_PRICE));
                    articleDTO.note = cursor.getFloat(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_NOTE));
                    articleDTO.url = cursor.getString(cursor.getColumnIndex(BaseContrat.ArticlesContrat.COLONNE_URL));
                }
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
            finally
            {
                cursor.close();
            }
        }

        return articleDTO;
    }


    public static long ajouterArticle(ArticleDTO articleDTO, Context context)
    {
        // récupération de la base de données :
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();

        // objet de valeurs :
        values = new ContentValues();
        values.put(BaseContrat.ArticlesContrat.COLONNE_NAME, articleDTO.name);
        values.put(BaseContrat.ArticlesContrat.COLONNE_DESCRIPTION, articleDTO.description);
        values.put(BaseContrat.ArticlesContrat.COLONNE_PRICE, articleDTO.price);
        values.put(BaseContrat.ArticlesContrat.COLONNE_NOTE, articleDTO.note);
        values.put(BaseContrat.ArticlesContrat.COLONNE_URL, articleDTO.url);


        // ajout :
        return db.insert(BaseContrat.ArticlesContrat.TABLE_ARTICLES, null, values);
    }

    public static long updateArticle(ArticleDTO articleDTO, Context context)
    {
        // récupération de la base de données :
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();

        // objet de valeurs :
        values = new ContentValues();
        values.put(BaseContrat.ArticlesContrat.COLONNE_NAME, articleDTO.name);
        values.put(BaseContrat.ArticlesContrat.COLONNE_DESCRIPTION, articleDTO.description);
        values.put(BaseContrat.ArticlesContrat.COLONNE_PRICE, articleDTO.price);
        values.put(BaseContrat.ArticlesContrat.COLONNE_NOTE, articleDTO.note);
        values.put(BaseContrat.ArticlesContrat.COLONNE_URL, articleDTO.url);

        // filtre (clause WHERE) :
        selection = BaseContrat.ArticlesContrat._ID + " = ? ";
        selectionArgs = new String[]{articleDTO.id+""};

        // requête :
        return db.update(BaseContrat.ArticlesContrat.TABLE_ARTICLES, values, selection, selectionArgs);
    }

    public static long deleteArticle(ArticleDTO articleDTO, Context context)
    {
        // récupération de la base de données :
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();

        // filtre (clause WHERE) :
        selection = BaseContrat.ArticlesContrat._ID + " = ? ";
        selectionArgs = new String[]{articleDTO.id+""};

        // requête :
        return db.delete(BaseContrat.ArticlesContrat.TABLE_ARTICLES, selection, selectionArgs);
    }

}