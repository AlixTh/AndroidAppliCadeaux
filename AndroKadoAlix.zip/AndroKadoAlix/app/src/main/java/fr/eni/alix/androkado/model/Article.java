package fr.eni.alix.androkado.model;

import org.parceler.Parcel;

@Parcel
public class Article {
    public String name;
    public String description;
    public float price;
    public float note;
    public String url;


    public Article(){}

    public Article(String name, String description, float price, float note, String url) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.note = note;
        this.url = url;
    }
}
