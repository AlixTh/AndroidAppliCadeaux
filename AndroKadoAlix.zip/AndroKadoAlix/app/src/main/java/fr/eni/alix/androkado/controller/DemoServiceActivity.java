package fr.eni.alix.androkado.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Toast;

import fr.eni.alix.androkado.R;
import fr.eni.alix.androkado.services.MonService;

public class DemoServiceActivity extends AppCompatActivity {

    private MonService monService = null;

    // Callback pour le binding, via un ServiceConnection :
    private ServiceConnection connexion = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            monService = ((MonService.MonBinder) binder).getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            monService = null;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_service);
    }


    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, MonService.class);
        bindService(intent, connexion, BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (monService != null) {
            unbindService(connexion);
        }
    }

    public void clicBoutonPlay(View view) {
        Intent intent = new Intent(this, MonService.class);
        intent.putExtra(MonService.EXTRA_COMMANDE, "play");
        startService(intent);
    }

    public void clicBoutonPause(View view) {
        Intent intent = new Intent(this, MonService.class);
        intent.putExtra(MonService.EXTRA_COMMANDE, "pause");
        startService(intent);
    }

    public void clicBoutonArreterService(View view) {
        Intent intent = new Intent(this, MonService.class);
        stopService(intent);
    }

    public void clicBoutonGetTitre(View view) {
        if (monService == null) return;
        String titreCourant = monService.getTitreCourant();
        Toast.makeText(this, titreCourant, Toast.LENGTH_LONG).show();
    }
}