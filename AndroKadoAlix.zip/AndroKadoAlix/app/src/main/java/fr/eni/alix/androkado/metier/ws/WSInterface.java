package fr.eni.alix.androkado.metier.ws;

import fr.eni.alix.androkado.model.Planete;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface WSInterface
{
    // appel get :
    @GET("/api/planets/{id}/")
    Call<Planete> getPlanete(@Path("id") int id);
}
